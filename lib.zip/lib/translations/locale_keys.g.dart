// DO NOT EDIT. This is code generated via package:easy_localization/generate.dart

// ignore_for_file: constant_identifier_names

abstract class  LocaleKeys {
  static const version = 'version';
  static const translation = 'translation';
  static const title = 'title';
  static const text_recognition_translation = 'text_recognition_translation';
  static const ocr_translation = 'ocr_translation';
  static const japanese = 'japanese';
  static const indonesian = 'indonesian';
  static const english = 'english';
  static const document_translation = 'document_translation';
  static const dictionary = 'dictionary';
  static const about = 'about';

}
