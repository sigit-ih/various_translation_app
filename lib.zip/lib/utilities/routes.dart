class Routes{
  static const String splashscreen = '/splashscreen';
  static const String mainscreen = '/mainscreen';
  static const String dictionaryscreen = '/submenu/dictionaryscreen';
  static const String wordtranslationscreen = '/submenu/wordtranslationscreen';
  static const String ocrtranslationscreen = '/submenu/ocrtranslationscreen';
  static const String documenttranslationscreen = '/submenu/documenttranslationscreen';
  static const String realtimetexttranslationscreen = '/submenu/realtimetexttranslationscreen';
  static const String aboutscreen = '/submenu/aboutscreen';
  
}