import 'package:flutter/material.dart';

class OCRTranslationScreen extends StatefulWidget {
  const OCRTranslationScreen({super.key});

  @override
  State<OCRTranslationScreen> createState() => _OCRTranslationScreenState();
}

class _OCRTranslationScreenState extends State<OCRTranslationScreen> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}