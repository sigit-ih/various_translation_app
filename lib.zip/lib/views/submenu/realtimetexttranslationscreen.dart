import 'package:flutter/material.dart';

class RealTimeTextTranslationScreen extends StatefulWidget {
  const RealTimeTextTranslationScreen({super.key});

  @override
  State<RealTimeTextTranslationScreen> createState() => _RealTimeTextTranslationScreenState();
}

class _RealTimeTextTranslationScreenState extends State<RealTimeTextTranslationScreen> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}