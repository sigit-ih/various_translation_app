import 'package:flutter/material.dart';

class WordTranslationScreen extends StatefulWidget {
  const WordTranslationScreen({super.key});

  @override
  State<WordTranslationScreen> createState() => _WordTranslationScreenState();
}

class _WordTranslationScreenState extends State<WordTranslationScreen> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}